package com.example.suitcase;

public interface ViewHolder {
}
